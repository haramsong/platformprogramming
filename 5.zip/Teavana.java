package com.cafe.menu;

import java.util.Objects;

public class Teavana extends Beverage{
    private int amount;

    public Teavana(String name) {
        super(name, 4100, "TALL");
    }

    @Override
    public boolean setSize(String size) {
        if (!Objects.equals(size, "GRANDE")) {
            super.setSize(size);
            return true;
        }
        return false;
    }
}
