package com.cafe.menu;

public class Coffee extends Beverage{
    private int defaultShot;

    public Coffee(String name) {
        super(name, 4100, "TALL");
    }

    @Override
    public boolean setSize(String size) {
        super.setSize(size);
        return true;
    }
}
