package com.cafe.order;
import com.cafe.menu.*;
public class OrderItem {
    Beverage beverage;
    int quantity;

    public OrderItem(Beverage newBeverage, int newQuantity) {
        this.beverage = newBeverage;
        this.quantity = newQuantity;
    }
    public String toString() {
        return "[ name=" + beverage.getName() + ", Price=" + beverage.getPrice() + ", size="+ beverage.getSize() + ", quantity=" + quantity + " ]";
    }

}
