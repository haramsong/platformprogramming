package com.cafe.menu;

public abstract class Beverage {
    public static final int TALL = 0;
    public static final int GRANDE = 1;
    public static final int VENTI = 2;

    String name;
    int basePrice;
    String size;
    int baseAmount;

    public Beverage(String beverageName, int beveragePrice, String bevarageSize) {
        this.name = beverageName;
        this.basePrice = beveragePrice;
        this.size = bevarageSize;
    }

    public int getPrice() {
        if (this.size.equals("TALL")) baseAmount = 0;
        else if (this.size.equals("GRANDE")) baseAmount = 1;
        else baseAmount = 2;
        return this.basePrice + 500 * baseAmount;
    }

    public String getName() {
        return name;
    }

    public int getBasePrice() {
        return basePrice;
    }

    public String getSize() {
        return size;
    }

    public boolean setSize(String size) {
        this.size = size;
        return true;
    }

    public boolean equals(String name) {
        if (this.name.hashCode() != name.hashCode()) return false;
        return true;
    }
}
