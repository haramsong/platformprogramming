package com.cafe.order;

import java.util.ArrayList;

public class Order {
    private ArrayList<OrderItem> items = new ArrayList<OrderItem>();



    public boolean setSize(String name, String size) {
        for ( int i = 0; i < items.size(); i++ ) {
            if ( items.get(i).beverage.equals(name))  {
                return items.get(i).beverage.setSize(size);
            }
        }
        return false;
    }

    public void add(OrderItem newItem) {
        items.add(items.size(), newItem);
    }

    public int cost() {
        int total = 0;
        for ( int i = 0; i < items.size(); i++ ) {
            total += items.get(i).beverage.getPrice() * items.get(i).quantity;
        }
        return total;
    }

    public void print() {
        String msg = "";
        for ( int i = 0; i < items.size(); i++ ) {
            msg += items.get(i);
            if ( i != items.size() - 1) {
                msg += "\n";
            }
        }
        System.out.println(msg);
        System.out.printf("Total : %,d%n", cost());
    }
}
