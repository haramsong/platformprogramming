import java.util.ArrayList;

public class FootballClub {
    private String name;
    private final int maxSquadSize = 25;

    private ArrayList<Player> squad = new ArrayList<Player>();

    public String toString() {
        String msg = "FootballClub Name: " + name + " Player Count: " + squad.size() + "\n";
        for ( int i = 0; i < squad.size(); i++ ) {
            msg += "\t" + squad.get(i) + "\n";
        }
        return msg;
    }

    public FootballClub(String clubName) {
        name = clubName;
    }


    public void addPlayer(Player newPlayer) {
        squad.add(squad.size(), newPlayer);
    }

    public Player findPlayer(String playerFirstName, int jerseyNumber) {
        for ( int i = 0; i < squad.size(); i++ ) {
            if ( squad.get(i).equals(playerFirstName, jerseyNumber)) return squad.get(i);
        }
        return null;
    }


    @Override
    public int hashCode(){
        return this.maxSquadSize;
    }
    public void removeAllPlayer() {
        squad.clear();
    }
}
