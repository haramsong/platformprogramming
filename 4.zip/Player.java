public class Player {
    private String firstName;
    private String lastName;
    private int jerseyNumber;

    public Player(String playerFirstName, String playerLastName, int playerJerseyNumber) {
        firstName = playerFirstName;
        lastName = playerLastName;
        jerseyNumber = playerJerseyNumber;
    }

    public String toString() {
        return "[" + this.lastName + ", " + this.firstName + " " + this.jerseyNumber + "]";
    }

    public boolean equals(String playerFirstName, int jerseyNumber) {
        if (this.firstName.hashCode() != playerFirstName.hashCode()) return false;
        if (this.jerseyNumber != jerseyNumber) return false;
        return true;
    }
}
