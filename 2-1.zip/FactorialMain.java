import java.util.Scanner;
public class FactorialMain {

    public static int factorial_num = 1;
    public static int factorial_temp = 1;
    public static void main(String[] args) {
        final Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int fac_num = scanner.nextInt();
        for (int i = 1; i <= fac_num; i ++ ) {
            System.out.format("Factorial of %d = %d\n", i, getFactorial(i));
        }
    }
    private static long getFactorial(final int n){
        if (n == 1) {
            factorial_temp = factorial_num;
            return factorial_num;
        }
        if (factorial_temp != 1){
            factorial_temp = 1;
            factorial_num = 1;
        }
        factorial_num = factorial_num * n;
        return getFactorial(n-1);
    }
}
