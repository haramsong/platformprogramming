import java.util.Scanner;
enum Command {
    QUIT, ADD, LIST, AVG, SUM, STD, INVALID;
}
public class ArrayEnum {
    public static void main(String[] args) {
        int [] values = new int[100];
        int index = 0;
        final Scanner scanner = new Scanner(System.in);

        while (true) {
            final Command command = getCommand(scanner);
            if (command == Command.QUIT) {
                System.out.println("Bye!");
                break;
            }
            switch (command) {
                case ADD:
                    final int newValue = getValue(scanner);
                    values[index] = newValue;
                    index++;
                    break;
                case LIST:
                    printList(values, index);
                    break;
                case AVG:
                    System.out.printf("%.2f%n", getAvg(values, index));
                    break;
                case SUM:
                    System.out.printf("%d%n", getSum(values, index));
                    break;
                case STD:
                    System.out.printf("%.2f%n", getStd(values, index));
                    break;
                case INVALID:
                    System.out.println("Invalid Command");
            }
        }
        scanner.close();
    }

    public static Command getCommand(final Scanner scanner) {
        String commandValue = scanner.next();
  
        Command command;
        try {
            command = Command.valueOf(commandValue.toUpperCase());
        }
        catch (IllegalArgumentException e) {
            command = Command.INVALID;
        }
        return command;
    }

    private static int getValue(final Scanner scanner) {
        String valueStr = scanner.nextLine().replace(" ", "");
        int addValue = Integer.parseInt(valueStr);
        return addValue;
    }

    private static void printList(int[] values, int index) {
        for (int i = 0; i < index; i++) {
            System.out.print(values[i] + " ");
        }
        System.out.print("\n");
    }

    private static float getAvg(int[] values, int index) {
        int avgNum = 0;
        for (int i = 0; i < index; i++) {
            avgNum += values[i];
        }
        return (float) avgNum / index;
    }

    private static int getSum(int[] values, int index) {
        int sumNum = 0;
        for (int i = 0; i < index; i++) {
            sumNum += values[i];
        }
        return sumNum;
    }

    private static float getStd(int[] values, int index) {
        int stdNum = 0;
        for (int i = 0; i < index; i++) {
            stdNum += Math.pow((values[i] - getAvg(values, index)), 2);
        }
        float variance = (float) stdNum / index;
        return (float) Math.sqrt(variance);
    }
}
