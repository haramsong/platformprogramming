package edu.pnu.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GenericList<T> {
    private static final int DEFAULT_SIZE = 10;
    private Object[] data;
    private int size = 0;
    
    // GenericList<T> genericList = new GenericList<T>();
    List<T> list = new ArrayList<T>(DEFAULT_SIZE);

//    public void setData(Object[] data) {
//        this.data = (Object[]) data;
//    }
//
//    public Object[] getData() {
//        return list;
//    }

    public T get(int i) {
        return (T) list.get(i);
    }

    public int size() {
        return list.size();
    }

    public void add(int len, T newPlayer) {
        list.add(len, newPlayer);
    }

    public void clear() {
        list.clear();
    }
}
